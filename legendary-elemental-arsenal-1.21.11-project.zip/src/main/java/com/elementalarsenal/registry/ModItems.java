package com.elementalarsenal.registry;

import com.elementalarsenal.ElementalArsenalMod;
import com.elementalarsenal.item.ElementType;
import com.elementalarsenal.item.ElementalWeaponItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.Unit;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ModItems {
    private static final Map<ElementType, Item> WEAPONS = new EnumMap<>(ElementType.class);

    public static final Item SOLARIS_EDGE = registerWeapon(ElementType.FIRE);
    public static final Item CRYO_HALBERD = registerWeapon(ElementType.ICE);
    public static final Item STORMCALLER_SPEAR = registerWeapon(ElementType.LIGHTNING);
    public static final Item VOID_REAVER = registerWeapon(ElementType.VOID);
    public static final Item CELESTIAL_LANCE = registerWeapon(ElementType.HOLY);

    public static final RegistryKey<ItemGroup> ARSENAL_GROUP_KEY = RegistryKey.of(
        RegistryKeys.ITEM_GROUP,
        Identifier.of(ElementalArsenalMod.MOD_ID, "arsenal")
    );

    private ModItems() {}

    private static Item registerWeapon(ElementType type) {
        Identifier id = Identifier.of(ElementalArsenalMod.MOD_ID, type.getId());
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);

        Item.Settings settings = new Item.Settings()
            .registryKey(key)
            .maxCount(1)
            .rarity(Rarity.EPIC)
            .fireproof()
            .sword(ToolMaterial.NETHERITE, type.getBonusAttackDamage(), type.getAttackSpeed())
            .component(DataComponentTypes.UNBREAKABLE, Unit.INSTANCE)
            .component(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true)
            .component(
                DataComponentTypes.CUSTOM_NAME,
                Text.translatable("item.elemental_arsenal." + type.getId())
                    .styled(s -> s.withColor(type.getPrimaryColor()).withBold(true).withItalic(false))
            )
            .component(DataComponentTypes.LORE, new LoreComponent(buildWeaponLore(type)));

        Item item = Registry.register(Registries.ITEM, key, new ElementalWeaponItem(type, settings));
        WEAPONS.put(type, item);
        return item;
    }

    private static List<Text> buildWeaponLore(ElementType type) {
        String prefix = "lore.elemental_arsenal." + type.getId();
        return List.of(
            Text.translatable(prefix + ".line1").formatted(Formatting.GRAY, Formatting.ITALIC),
            Text.translatable(prefix + ".line2").formatted(Formatting.DARK_GRAY, Formatting.ITALIC),
            Text.empty(),
            Text.translatable(prefix + ".slash").formatted(Formatting.GOLD),
            Text.translatable(prefix + ".skill").formatted(Formatting.AQUA),
            Text.translatable(prefix + ".ultimate").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)
        );
    }

    public static void register() {
        ItemGroup group = FabricItemGroup.builder()
            .icon(() -> new ItemStack(SOLARIS_EDGE))
            .displayName(Text.translatable("itemGroup.elemental_arsenal.arsenal").formatted(Formatting.GOLD, Formatting.BOLD))
            .entries((context, entries) -> {
                entries.add(SOLARIS_EDGE);
                entries.add(CRYO_HALBERD);
                entries.add(STORMCALLER_SPEAR);
                entries.add(VOID_REAVER);
                entries.add(CELESTIAL_LANCE);
            })
            .build();

        Registry.register(Registries.ITEM_GROUP, ARSENAL_GROUP_KEY, group);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(SOLARIS_EDGE);
            entries.add(CRYO_HALBERD);
            entries.add(STORMCALLER_SPEAR);
            entries.add(VOID_REAVER);
            entries.add(CELESTIAL_LANCE);
        });
    }
}
