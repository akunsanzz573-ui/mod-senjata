package com.elementalarsenal.registry;

import com.elementalarsenal.ElementalArsenalMod;
import com.elementalarsenal.item.ElementType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public final class ModSounds {
    public static final SoundEvent SOLARIS_RESONANCE = register("solaris_resonance");
    public static final SoundEvent CRYO_RESONANCE = register("cryo_resonance");
    public static final SoundEvent STORM_RESONANCE = register("storm_resonance");
    public static final SoundEvent VOID_RESONANCE = register("void_resonance");
    public static final SoundEvent HOLY_RESONANCE = register("holy_resonance");

    private ModSounds() {}

    private static SoundEvent register(String id) {
        Identifier identifier = Identifier.of(ElementalArsenalMod.MOD_ID, id);
        return Registry.register(Registries.SOUND_EVENT, identifier, SoundEvent.of(identifier));
    }

    public static void register() {}

    public static void playSlashLayered(ServerWorld world, Vec3d pos, ElementType element) {
        world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.2F, 0.85F);
        switch (element) {
            case FIRE -> {
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 1.1F, 0.75F);
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 0.8F, 1.25F);
            }
            case ICE -> {
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 1.0F, 0.65F);
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1.4F, 1.5F);
            }
            case LIGHTNING -> {
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ITEM_TRIDENT_THUNDER.value(), SoundCategory.PLAYERS, 0.55F, 1.75F);
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_BEEHIVE_WORK, SoundCategory.PLAYERS, 1.2F, 1.9F);
            }
            case VOID -> {
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 0.55F);
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_RESPAWN_ANCHOR_DEPLETE.value(), SoundCategory.PLAYERS, 0.9F, 1.2F);
            }
            case HOLY -> {
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_BELL_USE, SoundCategory.PLAYERS, 1.1F, 1.45F);
                world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_AMETHYST_CLUSTER_BREAK, SoundCategory.PLAYERS, 1.2F, 1.3F);
            }
        }
    }

    public static void playChargeTick(ServerWorld world, Vec3d pos, ElementType element, float progress) {
        float pitch = 0.55F + progress * 1.35F;
        switch (element) {
            case FIRE -> world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_FURNACE_FIRE_CRACKLE, SoundCategory.PLAYERS, 1.2F, pitch);
            case ICE -> world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_AMETHYST_BLOCK_STEP, SoundCategory.PLAYERS, 1.1F, pitch);
            case LIGHTNING -> world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_CONDUIT_AMBIENT_SHORT, SoundCategory.PLAYERS, 1.2F, pitch);
            case VOID -> world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.PLAYERS, 0.65F, pitch);
            case HOLY -> world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_CHISELED_BOOKSHELF_INSERT_ENCHANTED, SoundCategory.PLAYERS, 1.3F, pitch);
        }
    }

    public static void playUltimateDetonation(ServerWorld world, Vec3d pos, ElementType element) {
        world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 1.6F, 0.65F);
        world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ITEM_TRIDENT_THUNDER.value(), SoundCategory.PLAYERS, 1.4F, element == ElementType.VOID ? 0.5F : 1.1F);
        if (element == ElementType.HOLY) {
            world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.8F, 1.3F);
        } else if (element == ElementType.VOID) {
            world.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 1.5F, 0.65F);
        }
    }
}
