package com.elementalarsenal.registry;

import com.elementalarsenal.ElementalArsenalMod;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModParticles {
    public static final SimpleParticleType SOLAR_EMBER = register("solar_ember");
    public static final SimpleParticleType FROST_SHARD = register("frost_shard");
    public static final SimpleParticleType STORM_SPARK = register("storm_spark");
    public static final SimpleParticleType VOID_WISP = register("void_wisp");
    public static final SimpleParticleType HOLY_MOTE = register("holy_mote");

    private ModParticles() {}

    private static SimpleParticleType register(String name) {
        return Registry.register(
            Registries.PARTICLE_TYPE,
            Identifier.of(ElementalArsenalMod.MOD_ID, name),
            FabricParticleTypes.simple(true)
        );
    }

    public static void register() {}
}
