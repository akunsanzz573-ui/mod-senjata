package com.elementalarsenal.config;

import com.elementalarsenal.ElementalArsenalMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("elemental_arsenal.json");
    private static ModConfig INSTANCE = new ModConfig();

    public boolean ultimateBlockDamage = false;
    public int maxParticlesPerTick = 180;
    public double maxVfxRenderDistance = 48.0;
    public int maxAffectedEntities = 24;

    public Map<String, WeaponBalance> weapons = new LinkedHashMap<>();

    public static class WeaponBalance {
        public float slashDamage;
        public double slashRadius;
        public int slashCooldownTicks;

        public float skillDamage;
        public double skillRadius;
        public int skillCooldownTicks;

        public float ultimateDamage;
        public double ultimateRadius;
        public int ultimateCooldownTicks;

        public WeaponBalance() {}

        public WeaponBalance(
            float slashDamage, double slashRadius, int slashCooldownTicks,
            float skillDamage, double skillRadius, int skillCooldownTicks,
            float ultimateDamage, double ultimateRadius, int ultimateCooldownTicks
        ) {
            this.slashDamage = slashDamage;
            this.slashRadius = slashRadius;
            this.slashCooldownTicks = slashCooldownTicks;
            this.skillDamage = skillDamage;
            this.skillRadius = skillRadius;
            this.skillCooldownTicks = skillCooldownTicks;
            this.ultimateDamage = ultimateDamage;
            this.ultimateRadius = ultimateRadius;
            this.ultimateCooldownTicks = ultimateCooldownTicks;
        }
    }

    public ModConfig() {
        weapons.put("solaris_edge", new WeaponBalance(14.0F, 4.5, 18, 22.0F, 14.0, 120, 48.0F, 11.0, 400));
        weapons.put("cryo_halberd", new WeaponBalance(13.0F, 4.8, 20, 20.0F, 16.0, 130, 44.0F, 11.0, 420));
        weapons.put("stormcaller_spear", new WeaponBalance(12.5F, 4.5, 14, 21.0F, 18.0, 100, 46.0F, 12.0, 380));
        weapons.put("void_reaver", new WeaponBalance(15.0F, 5.0, 22, 24.0F, 9.0, 150, 52.0F, 13.0, 460));
        weapons.put("celestial_lance", new WeaponBalance(13.5F, 4.6, 18, 23.0F, 22.0, 130, 45.0F, 12.0, 420));
    }

    public static ModConfig get() {
        return INSTANCE;
    }

    public WeaponBalance getBalance(String weaponId) {
        return weapons.getOrDefault(weaponId, new WeaponBalance(13.0F, 4.5, 18, 20.0F, 12.0, 120, 45.0F, 11.0, 400));
    }

    public static void load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
                ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
                if (loaded != null && loaded.weapons != null && !loaded.weapons.isEmpty()) {
                    INSTANCE = loaded;
                }
            } catch (IOException e) {
                ElementalArsenalMod.LOGGER.error("Failed to read elemental_arsenal.json, using defaults", e);
            }
        }
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(INSTANCE, writer);
            }
        } catch (IOException e) {
            ElementalArsenalMod.LOGGER.error("Failed to save elemental_arsenal.json", e);
        }
    }
}
