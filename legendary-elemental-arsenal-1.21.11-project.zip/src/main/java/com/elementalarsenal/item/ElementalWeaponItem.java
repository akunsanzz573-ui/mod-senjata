package com.elementalarsenal.item;

import com.elementalarsenal.combat.WeaponCombatHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class ElementalWeaponItem extends Item {
    private final ElementType elementType;

    public ElementalWeaponItem(ElementType elementType, Settings settings) {
        super(settings);
        this.elementType = elementType;
    }

    public ElementType getElementType() {
        return elementType;
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (hand != Hand.MAIN_HAND || user.isSpectator() || !user.isAlive()) {
            return ActionResult.PASS;
        }
        if (!world.isClient() && user instanceof ServerPlayerEntity serverPlayer) {
            WeaponCombatHandler.tryExecuteAction(
                serverPlayer,
                elementType,
                WeaponCombatHandler.WeaponAction.SLASH
            );
        }
        return ActionResult.SUCCESS;
    }
}
