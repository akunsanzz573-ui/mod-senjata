package com.elementalarsenal.item;

import com.elementalarsenal.registry.ModParticles;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

public enum ElementType {
    FIRE(
        "solaris_edge",
        "Solaris, Edge of the Dying Star",
        0xFF6A00,
        0xFFF3B0,
        7.0F,
        -2.2F
    ),
    ICE(
        "cryo_halberd",
        "Glacies, Halberd of Absolute Zero",
        0x00D2FF,
        0xE8F9FD,
        6.5F,
        -2.3F
    ),
    LIGHTNING(
        "stormcaller_spear",
        "Fulminata, Spear of the Astral Tempest",
        0x9D4EDD,
        0xFFF75E,
        6.0F,
        -2.0F
    ),
    VOID(
        "void_reaver",
        "Nihilus, Scythe of the Event Horizon",
        0x7B2CBF,
        0xE0AAFF,
        8.0F,
        -2.4F
    ),
    HOLY(
        "celestial_lance",
        "Aurelia, Greatspear of the Seraphim",
        0xFFD166,
        0xFFFFFF,
        6.5F,
        -2.2F
    );

    private final String id;
    private final String displayName;
    private final int primaryColor;
    private final int flashColor;
    private final float bonusAttackDamage;
    private final float attackSpeed;

    ElementType(
        String id,
        String displayName,
        int primaryColor,
        int flashColor,
        float bonusAttackDamage,
        float attackSpeed
    ) {
        this.id = id;
        this.displayName = displayName;
        this.primaryColor = primaryColor;
        this.flashColor = flashColor;
        this.bonusAttackDamage = bonusAttackDamage;
        this.attackSpeed = attackSpeed;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getPrimaryColor() {
        return primaryColor;
    }

    public int getFlashColor() {
        return flashColor;
    }

    public float getBonusAttackDamage() {
        return bonusAttackDamage;
    }

    public float getAttackSpeed() {
        return attackSpeed;
    }

    public ParticleEffect getPrimaryParticle() {
        return switch (this) {
            case FIRE -> ModParticles.SOLAR_EMBER;
            case ICE -> ModParticles.FROST_SHARD;
            case LIGHTNING -> ModParticles.STORM_SPARK;
            case VOID -> ModParticles.VOID_WISP;
            case HOLY -> ModParticles.HOLY_MOTE;
        };
    }

    public ParticleEffect getSecondaryParticle() {
        return switch (this) {
            case FIRE -> ParticleTypes.FLAME;
            case ICE -> ParticleTypes.SNOWFLAKE;
            case LIGHTNING -> ParticleTypes.ELECTRIC_SPARK;
            case VOID -> ParticleTypes.REVERSE_PORTAL;
            case HOLY -> ParticleTypes.END_ROD;
        };
    }
}
