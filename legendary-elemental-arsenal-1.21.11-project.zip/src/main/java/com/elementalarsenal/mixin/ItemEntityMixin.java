package com.elementalarsenal.mixin;

import com.elementalarsenal.item.ElementType;
import com.elementalarsenal.item.ElementalWeaponItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin extends Entity {
    @Shadow
    public abstract ItemStack getStack();

    @Shadow
    public abstract void setNeverDespawn();

    @Shadow
    public abstract int getItemAge();

    protected ItemEntityMixin(EntityType<?> type, World world) {
        super(type, world);
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void elementalArsenal$onDroppedWeaponTick(CallbackInfo ci) {
        ItemStack stack = this.getStack();
        if (!(stack.getItem() instanceof ElementalWeaponItem weapon)) {
            return;
        }

        ElementType element = weapon.getElementType();
        this.setGlowing(true);
        this.setInvulnerable(true);
        this.setNeverDespawn();

        int age = this.getItemAge();
        if (this.isOnGround() || this.getVelocity().y < 0.0) {
            double hoverVel = Math.sin(age * 0.1) * 0.025 + 0.042;
            Vec3d vel = this.getVelocity();
            this.setVelocity(vel.x * 0.85, hoverVel, vel.z * 0.85);
        }

        World world = this.getWorld();
        if (world instanceof net.minecraft.server.world.ServerWorld serverWorld) {
            double x = this.getX();
            double y = this.getY() + 0.25;
            double z = this.getZ();

            if (age % 2 == 0) {
                for (int h = 0; h < 4; h++) {
                    serverWorld.spawnParticles(
                        element.getPrimaryParticle(),
                        x, y + h * 0.85, z,
                        1, 0.04, 0.05, 0.04, 0.01
                    );
                }
                serverWorld.spawnParticles(ParticleTypes.END_ROD, x, y + 0.2, z, 1, 0.02, 0.08, 0.02, 0.01);
            }

            double angle = age * 0.18;
            double radius = 0.55;
            serverWorld.spawnParticles(
                element.getSecondaryParticle(),
                x + Math.cos(angle) * radius,
                y + 0.15 + Math.sin(angle * 2.0) * 0.1,
                z + Math.sin(angle) * radius,
                1, 0.0, 0.0, 0.0, 0.0
            );

            if (age % 45 == 0) {
                serverWorld.playSound(
                    null, x, y, z,
                    SoundEvents.BLOCK_BEACON_AMBIENT, SoundCategory.AMBIENT, 0.35F,
                    element == ElementType.VOID ? 0.6F : 1.4F
                );
            }
        }
    }
}
