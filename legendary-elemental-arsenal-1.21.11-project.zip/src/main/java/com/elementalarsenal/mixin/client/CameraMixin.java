package com.elementalarsenal.mixin.client;

import com.elementalarsenal.client.ClientVfxState;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    public abstract float getYaw();

    @Shadow
    public abstract float getPitch();

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update", at = @At("TAIL"))
    private void elementalArsenal$applyCameraShake(
        BlockView area,
        Entity focusedEntity,
        boolean thirdPerson,
        boolean inverseView,
        float tickDelta,
        CallbackInfo ci
    ) {
        float shake = ClientVfxState.getCurrentShakeAmplitude(tickDelta);
        if (shake <= 0.001F || focusedEntity == null) {
            return;
        }

        double timePhase = ClientVfxState.isInHitStop()
            ? (focusedEntity.age * 1.9)
            : ((focusedEntity.age + tickDelta) * 2.35);

        float yawOffset = (float) (Math.sin(timePhase * 3.1) * shake * 4.2F);
        float pitchOffset = (float) (Math.cos(timePhase * 3.7) * shake * 3.5F);
        this.setRotation(this.getYaw() + yawOffset, this.getPitch() + pitchOffset);
    }
}
