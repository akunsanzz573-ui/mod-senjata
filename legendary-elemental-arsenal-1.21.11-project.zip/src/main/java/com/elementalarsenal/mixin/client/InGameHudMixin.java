package com.elementalarsenal.mixin.client;

import com.elementalarsenal.client.ClientVfxState;
import com.elementalarsenal.item.ElementType;
import com.elementalarsenal.item.ElementalWeaponItem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Shadow
    @Final
    private MinecraftClient client;

    @Inject(method = "render", at = @At("TAIL"))
    private void elementalArsenal$renderHudAndOverlays(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (this.client.player == null || this.client.options.hudHidden) {
            return;
        }

        int width = context.getScaledWindowWidth();
        int height = context.getScaledWindowHeight();

        // 1. Ultimate charge-up sky darkening overlay
        int skyDarkenArgb = ClientVfxState.getSkyDarkenArgb();
        if (skyDarkenArgb != 0) {
            context.fill(0, 0, width, height, skyDarkenArgb);
        }

        // 2. Elemental impact screen flash overlay
        int flashArgb = ClientVfxState.getFlashArgb();
        if (flashArgb != 0) {
            context.fill(0, 0, width, height, flashArgb);
        }

        // 3. Weapon ability cooldown bars above the hotbar when holding an ElementalWeaponItem
        if (this.client.player.getMainHandStack().getItem() instanceof ElementalWeaponItem weapon) {
            ElementType type = weapon.getElementType();
            int accent = 0xFF000000 | type.getPrimaryColor();

            int barWidth = 54;
            int barHeight = 4;
            int startX = (width / 2) - 86;
            int y = height - 52;

            drawAbilityBar(context, startX, y, barWidth, barHeight, 1.0F - ClientVfxState.getSlashRatio(), accent);
            drawAbilityBar(context, startX + 59, y, barWidth, barHeight, 1.0F - ClientVfxState.getSkillRatio(), accent);
            drawAbilityBar(context, startX + 118, y, barWidth, barHeight, 1.0F - ClientVfxState.getUltRatio(), 0xFFFFD166);
        }
    }

    private static void drawAbilityBar(DrawContext context, int x, int y, int width, int height, float readyFraction, int fillColor) {
        context.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xAA0A0A12);
        int filled = Math.round(width * Math.max(0.0F, Math.min(1.0F, readyFraction)));
        int color = (readyFraction >= 0.999F) ? fillColor : 0xAA666677;
        context.fill(x, y, x + filled, y + height, color);
    }
}
