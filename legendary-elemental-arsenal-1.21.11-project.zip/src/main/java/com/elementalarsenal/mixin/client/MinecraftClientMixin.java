package com.elementalarsenal.mixin.client;

import com.elementalarsenal.combat.WeaponCombatHandler.WeaponAction;
import com.elementalarsenal.item.ElementalWeaponItem;
import com.elementalarsenal.network.ModNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Shadow
    @Nullable
    public ClientPlayerEntity player;

    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void elementalArsenal$interceptLeftClickAttack(CallbackInfoReturnable<Boolean> cir) {
        if (this.player == null || this.player.isSpectator() || !this.player.isAlive()) {
            return;
        }
        if (this.player.getMainHandStack().getItem() instanceof ElementalWeaponItem) {
            WeaponAction action = this.player.isSneaking() ? WeaponAction.ULTIMATE : WeaponAction.SKILL;
            this.player.swingHand(Hand.MAIN_HAND);
            ClientPlayNetworking.send(new ModNetworking.WeaponActionPayload(action.ordinal()));
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "handleBlockBreaking", at = @At("HEAD"), cancellable = true)
    private void elementalArsenal$preventBlockBreakingWithWeapon(boolean breaking, CallbackInfo ci) {
        if (breaking && this.player != null && !this.player.isSpectator()
            && this.player.getMainHandStack().getItem() instanceof ElementalWeaponItem) {
            ci.cancel();
        }
    }
}
