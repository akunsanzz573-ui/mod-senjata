package com.elementalarsenal.network;

import com.elementalarsenal.ElementalArsenalMod;
import com.elementalarsenal.client.ClientVfxState;
import com.elementalarsenal.combat.WeaponCombatHandler;
import com.elementalarsenal.item.ElementalWeaponItem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public final class ModNetworking {
    private ModNetworking() {}

    public record WeaponActionPayload(int actionOrdinal) implements CustomPayload {
        public static final CustomPayload.Id<WeaponActionPayload> ID =
            new CustomPayload.Id<>(Identifier.of(ElementalArsenalMod.MOD_ID, "weapon_action"));

        public static final PacketCodec<RegistryByteBuf, WeaponActionPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, WeaponActionPayload::actionOrdinal,
            WeaponActionPayload::new
        );

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record ScreenEffectPayload(
        float shakeIntensity,
        int shakeTicks,
        int hitStopTicks,
        int flashColorRgb,
        int flashTicks,
        float skyDarkenIntensity,
        int skyDarkenTicks
    ) implements CustomPayload {
        public static final CustomPayload.Id<ScreenEffectPayload> ID =
            new CustomPayload.Id<>(Identifier.of(ElementalArsenalMod.MOD_ID, "screen_effect"));

        public static final PacketCodec<RegistryByteBuf, ScreenEffectPayload> CODEC = PacketCodec.of(
            (value, buf) -> {
                buf.writeFloat(value.shakeIntensity);
                buf.writeVarInt(value.shakeTicks);
                buf.writeVarInt(value.hitStopTicks);
                buf.writeInt(value.flashColorRgb);
                buf.writeVarInt(value.flashTicks);
                buf.writeFloat(value.skyDarkenIntensity);
                buf.writeVarInt(value.skyDarkenTicks);
            },
            buf -> new ScreenEffectPayload(
                buf.readFloat(),
                buf.readVarInt(),
                buf.readVarInt(),
                buf.readInt(),
                buf.readVarInt(),
                buf.readFloat(),
                buf.readVarInt()
            )
        );

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public record CooldownSyncPayload(
        int slashRemainingTicks,
        int slashTotalTicks,
        int skillRemainingTicks,
        int skillTotalTicks,
        int ultRemainingTicks,
        int ultTotalTicks
    ) implements CustomPayload {
        public static final CustomPayload.Id<CooldownSyncPayload> ID =
            new CustomPayload.Id<>(Identifier.of(ElementalArsenalMod.MOD_ID, "cooldown_sync"));

        public static final PacketCodec<RegistryByteBuf, CooldownSyncPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, CooldownSyncPayload::slashRemainingTicks,
            PacketCodecs.VAR_INT, CooldownSyncPayload::slashTotalTicks,
            PacketCodecs.VAR_INT, CooldownSyncPayload::skillRemainingTicks,
            PacketCodecs.VAR_INT, CooldownSyncPayload::skillTotalTicks,
            PacketCodecs.VAR_INT, CooldownSyncPayload::ultRemainingTicks,
            PacketCodecs.VAR_INT, CooldownSyncPayload::ultTotalTicks,
            CooldownSyncPayload::new
        );

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static void registerCommon() {
        PayloadTypeRegistry.playC2S().register(WeaponActionPayload.ID, WeaponActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ScreenEffectPayload.ID, ScreenEffectPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CooldownSyncPayload.ID, CooldownSyncPayload.CODEC);
    }

    public static void registerServerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(WeaponActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            context.server().execute(() -> {
                if (player == null || !player.isAlive() || player.isSpectator()) {
                    return;
                }
                if (!(player.getMainHandStack().getItem() instanceof ElementalWeaponItem weapon)) {
                    return;
                }
                WeaponCombatHandler.WeaponAction[] actions = WeaponCombatHandler.WeaponAction.values();
                int ord = payload.actionOrdinal();
                if (ord >= 0 && ord < actions.length) {
                    WeaponCombatHandler.tryExecuteAction(player, weapon.getElementType(), actions[ord]);
                }
            });
        });
    }

    public static void registerClientReceivers() {
        ClientPlayNetworking.registerGlobalReceiver(ScreenEffectPayload.ID, (payload, context) -> {
            context.client().execute(() -> ClientVfxState.triggerScreenEffect(
                payload.shakeIntensity(),
                payload.shakeTicks(),
                payload.hitStopTicks(),
                payload.flashColorRgb(),
                payload.flashTicks(),
                payload.skyDarkenIntensity(),
                payload.skyDarkenTicks()
            ));
        });

        ClientPlayNetworking.registerGlobalReceiver(CooldownSyncPayload.ID, (payload, context) -> {
            context.client().execute(() -> ClientVfxState.updateCooldowns(
                payload.slashRemainingTicks(),
                payload.slashTotalTicks(),
                payload.skillRemainingTicks(),
                payload.skillTotalTicks(),
                payload.ultRemainingTicks(),
                payload.ultTotalTicks()
            ));
        });
    }

    public static void broadcastScreenEffect(
        ServerWorld world,
        Vec3d origin,
        double radius,
        float shakeIntensity,
        int shakeTicks,
        int hitStopTicks,
        int flashColorRgb,
        int flashTicks,
        float skyDarkenIntensity,
        int skyDarkenTicks
    ) {
        for (ServerPlayerEntity player : PlayerLookup.around(world, origin, radius)) {
            double dist = Math.sqrt(player.squaredDistanceTo(origin));
            float attenuation = (float) Math.max(0.2, 1.0 - (dist / radius));
            ScreenEffectPayload scaled = new ScreenEffectPayload(
                shakeIntensity * attenuation,
                shakeTicks,
                dist < 8.0 ? hitStopTicks : 0,
                flashColorRgb,
                flashTicks,
                skyDarkenIntensity * attenuation,
                skyDarkenTicks
            );
            ServerPlayNetworking.send(player, scaled);
        }
    }
}
