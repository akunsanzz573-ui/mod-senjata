package com.elementalarsenal.util;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;

import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.IntConsumer;

public final class ServerTaskScheduler {
    private static final List<ScheduledSequence> ACTIVE_SEQUENCES = new CopyOnWriteArrayList<>();

    private static final class ScheduledSequence {
        final UUID ownerUuid;
        final int totalTicks;
        final IntConsumer tickCallback;
        int currentTick = 0;
        boolean cancelled = false;

        ScheduledSequence(UUID ownerUuid, int totalTicks, IntConsumer tickCallback) {
            this.ownerUuid = ownerUuid;
            this.totalTicks = totalTicks;
            this.tickCallback = tickCallback;
        }
    }

    private ServerTaskScheduler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(ServerTaskScheduler::onServerTick);
    }

    public static void scheduleSequence(UUID ownerUuid, int durationTicks, IntConsumer tickCallback) {
        ACTIVE_SEQUENCES.add(new ScheduledSequence(ownerUuid, durationTicks, tickCallback));
    }

    public static void cancelPlayerTasks(UUID ownerUuid) {
        for (ScheduledSequence seq : ACTIVE_SEQUENCES) {
            if (ownerUuid != null && ownerUuid.equals(seq.ownerUuid)) {
                seq.cancelled = true;
            }
        }
    }

    private static void onServerTick(MinecraftServer server) {
        if (ACTIVE_SEQUENCES.isEmpty()) {
            return;
        }
        Iterator<ScheduledSequence> it = ACTIVE_SEQUENCES.iterator();
        while (it.hasNext()) {
            ScheduledSequence seq = it.next();
            if (seq.cancelled) {
                ACTIVE_SEQUENCES.remove(seq);
                continue;
            }
            try {
                seq.tickCallback.accept(seq.currentTick);
            } catch (Exception ignored) {
                seq.cancelled = true;
            }
            seq.currentTick++;
            if (seq.currentTick >= seq.totalTicks || seq.cancelled) {
                ACTIVE_SEQUENCES.remove(seq);
            }
        }
    }
}
