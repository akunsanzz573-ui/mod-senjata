package com.elementalarsenal.util;

import com.elementalarsenal.combat.WeaponCombatHandler.WeaponAction;
import com.elementalarsenal.config.ModConfig;
import com.elementalarsenal.item.ElementType;
import com.elementalarsenal.item.ElementalWeaponItem;
import com.elementalarsenal.network.ModNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CooldownManager {
    private static final Map<UUID, EnumMap<ElementType, long[]>> PLAYER_COOLDOWNS = new ConcurrentHashMap<>();

    private CooldownManager() {}

    public static int getConfiguredCooldown(ElementType type, WeaponAction action) {
        ModConfig.WeaponBalance bal = ModConfig.get().getBalance(type.getId());
        return switch (action) {
            case SLASH -> Math.max(1, bal.slashCooldownTicks);
            case SKILL -> Math.max(1, bal.skillCooldownTicks);
            case ULTIMATE -> Math.max(1, bal.ultimateCooldownTicks);
        };
    }

    public static int getRemainingTicks(ServerPlayerEntity player, ElementType type, WeaponAction action) {
        long now = player.getServerWorld().getTime();
        EnumMap<ElementType, long[]> map = PLAYER_COOLDOWNS.get(player.getUuid());
        if (map == null) {
            return 0;
        }
        long[] expirations = map.get(type);
        if (expirations == null) {
            return 0;
        }
        long rem = expirations[action.ordinal()] - now;
        return rem > 0 ? (int) rem : 0;
    }

    public static boolean tryConsumeCooldown(ServerPlayerEntity player, ElementType type, WeaponAction action) {
        int remaining = getRemainingTicks(player, type, action);
        if (remaining > 0) {
            float seconds = remaining / 20.0F;
            player.sendMessage(
                Text.literal(String.format("✦ %s on cooldown (%.1fs) ✦", action.name(), seconds))
                    .formatted(Formatting.RED),
                true
            );
            syncToClient(player);
            return false;
        }

        int duration = getConfiguredCooldown(type, action);
        long now = player.getServerWorld().getTime();
        PLAYER_COOLDOWNS
            .computeIfAbsent(player.getUuid(), u -> new EnumMap<>(ElementType.class))
            .computeIfAbsent(type, t -> new long[WeaponAction.values().length])[action.ordinal()] = now + duration;

        syncToClient(player);
        return true;
    }

    public static void syncToClient(ServerPlayerEntity player) {
        if (!(player.getMainHandStack().getItem() instanceof ElementalWeaponItem weapon)) {
            return;
        }
        ElementType type = weapon.getElementType();
        int slashRem = getRemainingTicks(player, type, WeaponAction.SLASH);
        int skillRem = getRemainingTicks(player, type, WeaponAction.SKILL);
        int ultRem = getRemainingTicks(player, type, WeaponAction.ULTIMATE);

        ServerPlayNetworking.send(player, new ModNetworking.CooldownSyncPayload(
            slashRem, getConfiguredCooldown(type, WeaponAction.SLASH),
            skillRem, getConfiguredCooldown(type, WeaponAction.SKILL),
            ultRem, getConfiguredCooldown(type, WeaponAction.ULTIMATE)
        ));
    }

    public static void clearPlayer(UUID uuid) {
        PLAYER_COOLDOWNS.remove(uuid);
    }
}
