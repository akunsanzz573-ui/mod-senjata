package com.elementalarsenal.vfx;

import com.elementalarsenal.config.ModConfig;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

public final class ParticleMath {
    private ParticleMath() {}

    public static double easeOutCubic(double t) {
        double inv = 1.0 - Math.max(0.0, Math.min(1.0, t));
        return 1.0 - inv * inv * inv;
    }

    public static double easeInOutSine(double t) {
        return -(Math.cos(Math.PI * Math.max(0.0, Math.min(1.0, t))) - 1.0) / 2.0;
    }

    public static void spawnCrescentArc(
        ServerWorld world,
        Vec3d origin,
        Vec3d forward,
        double radius,
        double arcDegrees,
        double tiltDegrees,
        ParticleEffect primary,
        ParticleEffect secondary,
        int points
    ) {
        int cappedPoints = Math.min(points, ModConfig.get().maxParticlesPerTick / 2);
        Vec3d fwd = forward.normalize();
        Vec3d worldUp = Math.abs(fwd.y) > 0.92 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        Vec3d right = fwd.crossProduct(worldUp).normalize();
        Vec3d up = right.crossProduct(fwd).normalize();

        double tiltRad = Math.toRadians(tiltDegrees);
        Vec3d tiltedRight = right.multiply(Math.cos(tiltRad)).add(up.multiply(Math.sin(tiltRad)));
        Vec3d tiltedUp = up.multiply(Math.cos(tiltRad)).subtract(right.multiply(Math.sin(tiltRad)));

        double halfArc = Math.toRadians(arcDegrees * 0.5);
        for (int i = 0; i <= cappedPoints; i++) {
            double u = (double) i / cappedPoints;
            double angle = -halfArc + (2.0 * halfArc * u);
            double envelope = Math.sin(u * Math.PI);
            for (int layer = 0; layer < 3; layer++) {
                double r = radius * (0.78 + layer * 0.11 * envelope);
                Vec3d dir = fwd.multiply(Math.cos(angle)).add(tiltedRight.multiply(Math.sin(angle)));
                Vec3d pos = origin.add(dir.multiply(r)).add(tiltedUp.multiply((layer - 1) * 0.08 * envelope));

                ParticleEffect effect = (layer == 1) ? primary : secondary;
                world.spawnParticles(effect, pos.x, pos.y, pos.z, 1, 0.02, 0.02, 0.02, 0.01);
            }
        }
    }

    public static void spawnRing(
        ServerWorld world,
        Vec3d center,
        double radius,
        int count,
        ParticleEffect particle,
        double radialSpeed
    ) {
        int capped = Math.min(count, ModConfig.get().maxParticlesPerTick);
        for (int i = 0; i < capped; i++) {
            double angle = (2.0 * Math.PI * i) / capped;
            double dx = Math.cos(angle);
            double dz = Math.sin(angle);
            double x = center.x + dx * radius;
            double z = center.z + dz * radius;
            world.spawnParticles(particle, x, center.y, z, 1, dx * radialSpeed, 0.01, dz * radialSpeed, radialSpeed);
        }
    }

    public static void spawnJaggedLightningBolt(
        ServerWorld world,
        Vec3d start,
        Vec3d end,
        ParticleEffect primary,
        ParticleEffect secondary,
        int segments,
        double jitter
    ) {
        Vec3d prev = start;
        Vec3d diff = end.subtract(start);
        for (int i = 1; i <= segments; i++) {
            double t = (double) i / segments;
            Vec3d base = start.add(diff.multiply(t));
            if (i < segments) {
                double offsetScale = Math.sin(t * Math.PI) * jitter;
                base = base.add(
                    (world.random.nextDouble() - 0.5) * offsetScale,
                    (world.random.nextDouble() - 0.5) * offsetScale,
                    (world.random.nextDouble() - 0.5) * offsetScale
                );
            }
            spawnLine(world, prev, base, primary, 4);
            world.spawnParticles(secondary, base.x, base.y, base.z, 1, 0.02, 0.02, 0.02, 0.02);
            prev = base;
        }
    }

    public static void spawnLine(
        ServerWorld world,
        Vec3d start,
        Vec3d end,
        ParticleEffect particle,
        int points
    ) {
        for (int i = 0; i <= points; i++) {
            double t = (double) i / Math.max(1, points);
            Vec3d p = start.lerp(end, t);
            world.spawnParticles(particle, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    public static void spawnSacredMandala(
        ServerWorld world,
        Vec3d center,
        double radius,
        int vertices,
        double rotationRad,
        ParticleEffect primary,
        ParticleEffect secondary
    ) {
        spawnRing(world, center, radius, vertices * 6, primary, 0.0);
        spawnRing(world, center, radius * 0.65, vertices * 4, secondary, 0.0);
        for (int i = 0; i < vertices; i++) {
            double a1 = rotationRad + (2.0 * Math.PI * i) / vertices;
            double a2 = rotationRad + (2.0 * Math.PI * ((i + 2) % vertices)) / vertices;
            Vec3d p1 = center.add(Math.cos(a1) * radius, 0.05, Math.sin(a1) * radius);
            Vec3d p2 = center.add(Math.cos(a2) * radius, 0.05, Math.sin(a2) * radius);
            spawnLine(world, p1, p2, secondary, 8);
        }
    }
}
