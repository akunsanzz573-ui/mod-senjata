package com.elementalarsenal.client;

public final class ClientVfxState {
    private static float shakeIntensity = 0.0F;
    private static int shakeTicksRemaining = 0;
    private static int shakeTicksTotal = 1;

    private static int hitStopTicksRemaining = 0;

    private static int flashColorRgb = 0xFFFFFF;
    private static int flashTicksRemaining = 0;
    private static int flashTicksTotal = 1;

    private static float skyDarkenIntensity = 0.0F;
    private static int skyDarkenTicksRemaining = 0;
    private static int skyDarkenTicksTotal = 1;

    private static int slashRem = 0, slashTotal = 20;
    private static int skillRem = 0, skillTotal = 120;
    private static int ultRem = 0, ultTotal = 400;

    private ClientVfxState() {}

    public static void triggerScreenEffect(
        float shake,
        int shakeDuration,
        int hitStopDuration,
        int flashRgb,
        int flashDuration,
        float skyDarken,
        int skyDarkenDuration
    ) {
        if (shake > shakeIntensity || shakeTicksRemaining <= 0) {
            shakeIntensity = shake;
            shakeTicksRemaining = shakeDuration;
            shakeTicksTotal = Math.max(1, shakeDuration);
        }
        if (hitStopDuration > hitStopTicksRemaining) {
            hitStopTicksRemaining = hitStopDuration;
        }
        if (flashDuration > 0) {
            flashColorRgb = flashRgb;
            flashTicksRemaining = flashDuration;
            flashTicksTotal = Math.max(1, flashDuration);
        }
        if (skyDarkenDuration > 0) {
            skyDarkenIntensity = skyDarken;
            skyDarkenTicksRemaining = skyDarkenDuration;
            skyDarkenTicksTotal = Math.max(1, skyDarkenDuration);
        }
    }

    public static void updateCooldowns(int sRem, int sTot, int skRem, int skTot, int uRem, int uTot) {
        slashRem = sRem;
        slashTotal = Math.max(1, sTot);
        skillRem = skRem;
        skillTotal = Math.max(1, skTot);
        ultRem = uRem;
        ultTotal = Math.max(1, uTot);
    }

    public static void tick() {
        if (shakeTicksRemaining > 0) shakeTicksRemaining--;
        if (hitStopTicksRemaining > 0) hitStopTicksRemaining--;
        if (flashTicksRemaining > 0) flashTicksRemaining--;
        if (skyDarkenTicksRemaining > 0) skyDarkenTicksRemaining--;
        if (slashRem > 0) slashRem--;
        if (skillRem > 0) skillRem--;
        if (ultRem > 0) ultRem--;
    }

    public static float getCurrentShakeAmplitude(float tickDelta) {
        if (shakeTicksRemaining <= 0) return 0.0F;
        float progress = Math.max(0.0F, (shakeTicksRemaining - tickDelta) / (float) shakeTicksTotal);
        return shakeIntensity * progress * progress;
    }

    public static boolean isInHitStop() {
        return hitStopTicksRemaining > 0;
    }

    public static int getFlashArgb() {
        if (flashTicksRemaining <= 0) return 0;
        float ratio = (float) flashTicksRemaining / (float) flashTicksTotal;
        int alpha = Math.min(135, Math.max(0, (int) (ratio * ratio * 135.0F)));
        return (alpha << 24) | (flashColorRgb & 0xFFFFFF);
    }

    public static int getSkyDarkenArgb() {
        if (skyDarkenTicksRemaining <= 0) return 0;
        float ratio = (float) skyDarkenTicksRemaining / (float) skyDarkenTicksTotal;
        float envelope = (float) Math.sin(ratio * Math.PI);
        int alpha = Math.min(170, Math.max(0, (int) (skyDarkenIntensity * envelope * 170.0F)));
        return (alpha << 24) | 0x05020A;
    }

    public static float getSlashRatio() {
        return Math.min(1.0F, Math.max(0.0F, (float) slashRem / slashTotal));
    }

    public static float getSkillRatio() {
        return Math.min(1.0F, Math.max(0.0F, (float) skillRem / skillTotal));
    }

    public static float getUltRatio() {
        return Math.min(1.0F, Math.max(0.0F, (float) ultRem / ultTotal));
    }
}
