package com.elementalarsenal;

import com.elementalarsenal.combat.WeaponCombatHandler;
import com.elementalarsenal.config.ModConfig;
import com.elementalarsenal.item.ElementalWeaponItem;
import com.elementalarsenal.network.ModNetworking;
import com.elementalarsenal.registry.ModItems;
import com.elementalarsenal.registry.ModParticles;
import com.elementalarsenal.registry.ModSounds;
import com.elementalarsenal.util.CooldownManager;
import com.elementalarsenal.util.ServerTaskScheduler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ElementalArsenalMod implements ModInitializer {
    public static final String MOD_ID = "elemental_arsenal";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModConfig.load();
        ModSounds.register();
        ModParticles.register();
        ModItems.register();
        ModNetworking.registerCommon();
        ModNetworking.registerServerReceivers();
        ServerTaskScheduler.register();

        ServerTickEvents.END_WORLD_TICK.register(this::onWorldTick);

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            if (handler.player != null) {
                CooldownManager.clearPlayer(handler.player.getUuid());
                ServerTaskScheduler.cancelPlayerTasks(handler.player.getUuid());
            }
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayerEntity player) {
                ServerTaskScheduler.cancelPlayerTasks(player.getUuid());
            }
        });

        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
            ServerTaskScheduler.cancelPlayerTasks(player.getUuid());
            CooldownManager.syncToClient(player);
        });

        LOGGER.info("Legendary Elemental Arsenal initialized for Minecraft 1.21.11.");
    }

    private void onWorldTick(ServerWorld world) {
        long time = world.getTime();
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (player.isSpectator() || !player.isAlive()) {
                continue;
            }
            if (player.getMainHandStack().getItem() instanceof ElementalWeaponItem weapon) {
                WeaponCombatHandler.tickHeldPassiveServer(world, player, weapon.getElementType(), time);
                if (time % 5 == 0) {
                    CooldownManager.syncToClient(player);
                }
            }
        }
    }
}
