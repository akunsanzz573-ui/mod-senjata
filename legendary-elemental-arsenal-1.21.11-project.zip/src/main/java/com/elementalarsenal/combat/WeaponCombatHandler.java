package com.elementalarsenal.combat;

import com.elementalarsenal.config.ModConfig;
import com.elementalarsenal.item.ElementType;
import com.elementalarsenal.network.ModNetworking;
import com.elementalarsenal.registry.ModSounds;
import com.elementalarsenal.util.CooldownManager;
import com.elementalarsenal.util.ServerTaskScheduler;
import com.elementalarsenal.vfx.ParticleMath;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.EntityTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class WeaponCombatHandler {
    public enum WeaponAction {
        SLASH,
        SKILL,
        ULTIMATE
    }

    private WeaponCombatHandler() {}

    public static void tickHeldPassiveServer(ServerWorld world, ServerPlayerEntity player, ElementType element, long time) {
        if (time % 20 == 0) {
            switch (element) {
                case FIRE -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 45, 0, true, false, true));
                case ICE -> {
                    if (player.isSneaking()) {
                        BlockPos below = player.getBlockPos().down();
                        if (world.getBlockState(below).isOf(Blocks.WATER)) {
                            world.setBlockState(below, Blocks.FROSTED_ICE.getDefaultState());
                        }
                    }
                }
                case LIGHTNING -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 45, 0, true, false, true));
                case VOID -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 240, 0, true, false, true));
                case HOLY -> {
                    if (player.getHealth() < player.getMaxHealth()) {
                        player.heal(0.5F);
                    }
                }
            }
        }
        if (time % 60 == 0) {
            world.playSound(
                null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 0.25F,
                element == ElementType.VOID ? 0.55F : 1.35F
            );
        }
    }

    public static void tryExecuteAction(ServerPlayerEntity player, ElementType element, WeaponAction action) {
        if (player.isSpectator() || !player.isAlive() || player.isRemoved()) {
            return;
        }
        if (!CooldownManager.tryConsumeCooldown(player, element, action)) {
            return;
        }

        ServerWorld world = player.getServerWorld();
        ModConfig.WeaponBalance bal = ModConfig.get().getBalance(element.getId());

        switch (action) {
            case SLASH -> executeSlash(world, player, element, bal);
            case SKILL -> executeSkill(world, player, element, bal);
            case ULTIMATE -> executeUltimate(world, player, element, bal);
        }
    }

    private static void executeSlash(ServerWorld world, ServerPlayerEntity player, ElementType element, ModConfig.WeaponBalance bal) {
        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d slashOrigin = eye.add(look.multiply(0.85)).add(0, -0.25, 0);

        ModSounds.playSlashLayered(world, slashOrigin, element);

        double tilt = (world.getTime() % 2 == 0) ? 18.0 : -18.0;
        ParticleMath.spawnCrescentArc(
            world, slashOrigin, look, bal.slashRadius * 0.75, 145.0, tilt,
            element.getPrimaryParticle(), element.getSecondaryParticle(), 36
        );

        ServerTaskScheduler.scheduleSequence(player.getUuid(), 4, tick -> {
            if (tick == 2 && player.isAlive()) {
                ParticleMath.spawnCrescentArc(
                    world, slashOrigin.add(look.multiply(0.35)), look, bal.slashRadius * 0.88, 155.0, -tilt * 0.5,
                    element.getSecondaryParticle(), element.getPrimaryParticle(), 28
                );
            }
        });

        if (element == ElementType.LIGHTNING) {
            player.addVelocity(look.x * 0.55, 0.12, look.z * 0.55);
            player.velocityModified = true;
        }

        List<LivingEntity> targets = getTargetsInCone(world, player, slashOrigin, look, bal.slashRadius, 150.0);
        DamageSource source = world.getDamageSources().playerAttack(player);

        for (LivingEntity target : targets) {
            float dmg = bal.slashDamage;
            if (element == ElementType.HOLY && target.getType().isIn(EntityTypeTags.UNDEAD)) {
                dmg *= 1.5F;
            }
            if (target.damage(world, source, dmg)) {
                applyElementStatus(world, player, target, element, 1);
                if (element == ElementType.VOID) {
                    Vec3d pull = player.getPos().subtract(target.getPos()).normalize().multiply(0.45);
                    target.addVelocity(pull.x, 0.18, pull.z);
                    player.heal(1.5F);
                } else {
                    target.takeKnockback(0.75, -look.x, -look.z);
                }
                target.velocityModified = true;
                world.spawnParticles(element.getPrimaryParticle(), target.getX(), target.getBodyY(0.5), target.getZ(), 14, 0.25, 0.25, 0.25, 0.08);
            }
        }

        int hitStop = targets.isEmpty() ? 0 : 3;
        ModNetworking.broadcastScreenEffect(
            world, slashOrigin, ModConfig.get().maxVfxRenderDistance,
            targets.isEmpty() ? 0.22F : 0.45F, 8, hitStop, element.getFlashColor(), targets.isEmpty() ? 0 : 4, 0.0F, 0
        );
    }

    private static void executeSkill(ServerWorld world, ServerPlayerEntity player, ElementType element, ModConfig.WeaponBalance bal) {
        Vec3d origin = player.getPos();
        Vec3d look = player.getRotationVec(1.0F).normalize();
        Vec3d flatLook = new Vec3d(look.x, 0, look.z).lengthSquared() > 1.0E-4
            ? new Vec3d(look.x, 0, look.z).normalize()
            : new Vec3d(0, 0, 1);

        switch (element) {
            case FIRE -> {
                ServerTaskScheduler.scheduleSequence(player.getUuid(), 35, tick -> {
                    if (tick < 5) {
                        ModSounds.playChargeTick(world, origin, element, tick / 5.0F);
                        ParticleMath.spawnRing(world, origin.add(0, 0.2, 0), 1.5, 20, element.getPrimaryParticle(), 0.04);
                    } else if (tick <= 25 && (tick - 5) % 3 == 0) {
                        int step = (tick - 5) / 3 + 1;
                        double dist = (step / 7.0) * bal.skillRadius;
                        Vec3d geyserPos = origin.add(flatLook.multiply(dist));
                        world.playSound(null, geyserPos.x, geyserPos.y, geyserPos.z, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 0.9F, 1.15F);
                        ParticleMath.spawnRing(world, geyserPos.add(0, 0.15, 0), 1.8, 24, ParticleTypes.FLAME, 0.05);
                        for (int h = 0; h < 8; h++) {
                            world.spawnParticles(element.getPrimaryParticle(), geyserPos.x, geyserPos.y + h * 0.45, geyserPos.z, 5, 0.3, 0.2, 0.3, 0.04);
                        }
                        for (LivingEntity target : getTargetsAround(world, player, geyserPos, 2.5)) {
                            target.damage(world, world.getDamageSources().playerAttack(player), bal.skillDamage);
                            target.setOnFireFor(8);
                            target.addVelocity(0, 0.62, 0);
                            target.velocityModified = true;
                        }
                    }
                });
            }
            case ICE -> {
                ServerTaskScheduler.scheduleSequence(player.getUuid(), 32, tick -> {
                    if (tick < 4) {
                        ModSounds.playChargeTick(world, origin, element, tick / 4.0F);
                    } else if (tick <= 24 && (tick - 4) % 2 == 0) {
                        int idx = (tick - 4) / 2 + 1;
                        double dist = (idx / 10.0) * bal.skillRadius;
                        Vec3d spikeBase = origin.add(flatLook.multiply(dist));
                        world.playSound(null, spikeBase.x, spikeBase.y, spikeBase.z, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.PLAYERS, 1.0F, 0.75F + idx * 0.05F);
                        Vec3d tip = spikeBase.add(flatLook.multiply(0.6)).add(0, 2.8, 0);
                        ParticleMath.spawnLine(world, spikeBase, tip, element.getPrimaryParticle(), 14);
                        ParticleMath.spawnRing(world, spikeBase.add(0, 0.1, 0), 1.4, 16, ParticleTypes.SNOWFLAKE, 0.02);

                        for (LivingEntity target : getTargetsAround(world, player, spikeBase, 2.2)) {
                            target.damage(world, world.getDamageSources().freeze(), bal.skillDamage);
                            applyElementStatus(world, player, target, ElementType.ICE, 2);
                        }
                    }
                });
            }
            case LIGHTNING -> {
                Vec3d start = player.getEyePos().add(look.multiply(0.5));
                Vec3d beamEnd = start.add(look.multiply(bal.skillRadius));
                List<LivingEntity> initialCandidates = getTargetsAround(world, player, start.lerp(beamEnd, 0.5), bal.skillRadius * 0.6);
                initialCandidates.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(start)));

                if (initialCandidates.isEmpty()) {
                    ParticleMath.spawnJaggedLightningBolt(world, start, beamEnd, element.getPrimaryParticle(), ParticleTypes.ELECTRIC_SPARK, 10, 0.45);
                    ModSounds.playSlashLayered(world, start, element);
                } else {
                    Set<UUID> hitSet = new HashSet<>();
                    List<LivingEntity> chainOrder = new ArrayList<>();
                    LivingEntity current = initialCandidates.get(0);
                    chainOrder.add(current);
                    hitSet.add(current.getUuid());

                    for (int hop = 0; hop < 5; hop++) {
                        LivingEntity last = chainOrder.get(chainOrder.size() - 1);
                        LivingEntity next = getTargetsAround(world, player, last.getPos(), 8.0).stream()
                            .filter(e -> !hitSet.contains(e.getUuid()))
                            .min(Comparator.comparingDouble(e -> e.squaredDistanceTo(last)))
                            .orElse(null);
                        if (next == null) break;
                        chainOrder.add(next);
                        hitSet.add(next.getUuid());
                    }

                    ServerTaskScheduler.scheduleSequence(player.getUuid(), chainOrder.size() * 3, tick -> {
                        if (tick % 3 == 0) {
                            int link = tick / 3;
                            if (link < chainOrder.size()) {
                                LivingEntity target = chainOrder.get(link);
                                Vec3d from = (link == 0) ? player.getEyePos() : chainOrder.get(link - 1).getEyePos();
                                Vec3d to = new Vec3d(target.getX(), target.getBodyY(0.6), target.getZ());
                                ParticleMath.spawnJaggedLightningBolt(world, from, to, element.getPrimaryParticle(), ParticleTypes.ELECTRIC_SPARK, 8, 0.38);
                                world.playSound(null, to.x, to.y, to.z, SoundEvents.ITEM_TRIDENT_THUNDER.value(), SoundCategory.PLAYERS, 0.85F, 1.35F + link * 0.15F);
                                target.damage(world, world.getDamageSources().lightningBolt(), bal.skillDamage * (float) Math.pow(0.9, link));
                                applyElementStatus(world, player, target, ElementType.LIGHTNING, 2);
                            }
                        }
                    });
                }
            }
            case VOID -> {
                Vec3d vortexCenter = player.getEyePos().add(look.multiply(7.0));
                ServerTaskScheduler.scheduleSequence(player.getUuid(), 45, tick -> {
                    if (tick < 38) {
                        if (tick % 4 == 0) {
                            ModSounds.playChargeTick(world, vortexCenter, element, tick / 38.0F);
                        }
                        ParticleMath.spawnRing(world, vortexCenter, 2.6 * (1.0 - tick / 45.0), 20, element.getPrimaryParticle(), -0.05);
                        world.spawnParticles(ParticleTypes.PORTAL, vortexCenter.x, vortexCenter.y, vortexCenter.z, 12, 0.5, 0.5, 0.5, 0.25);

                        for (LivingEntity target : getTargetsAround(world, player, vortexCenter, bal.skillRadius)) {
                            Vec3d pull = vortexCenter.subtract(target.getPos()).normalize().multiply(0.22);
                            target.addVelocity(pull.x, pull.y * 0.5 + 0.04, pull.z);
                            target.velocityModified = true;
                            if (tick % 10 == 0) {
                                target.damage(world, world.getDamageSources().magic(), bal.skillDamage * 0.2F);
                            }
                        }
                    } else if (tick == 38) {
                        ModSounds.playUltimateDetonation(world, vortexCenter, element);
                        ParticleMath.spawnRing(world, vortexCenter, 4.5, 48, element.getPrimaryParticle(), 0.25);
                        for (LivingEntity target : getTargetsAround(world, player, vortexCenter, bal.skillRadius * 0.8)) {
                            target.damage(world, world.getDamageSources().outOfWorld(), bal.skillDamage);
                            applyElementStatus(world, player, target, ElementType.VOID, 2);
                        }
                        ModNetworking.broadcastScreenEffect(world, vortexCenter, 32.0, 0.6F, 12, 4, element.getFlashColor(), 6, 0.0F, 0);
                    }
                });
            }
            case HOLY -> {
                ServerTaskScheduler.scheduleSequence(player.getUuid(), 26, tick -> {
                    Vec3d eyeNow = player.getEyePos();
                    Vec3d lookNow = player.getRotationVec(1.0F).normalize();
                    if (tick < 8) {
                        ModSounds.playChargeTick(world, eyeNow, element, tick / 8.0F);
                        ParticleMath.spawnSacredMandala(world, eyeNow.add(lookNow.multiply(1.8)), 1.4, 6, tick * 0.25, element.getPrimaryParticle(), ParticleTypes.END_ROD);
                    } else if (tick == 8) {
                        world.playSound(null, eyeNow.x, eyeNow.y, eyeNow.z, SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 1.5F, 1.4F);
                        Vec3d beamEnd = eyeNow.add(lookNow.multiply(bal.skillRadius));
                        ParticleMath.spawnLine(world, eyeNow.add(lookNow), beamEnd, element.getPrimaryParticle(), 64);
                        ParticleMath.spawnLine(world, eyeNow.add(lookNow), beamEnd, ParticleTypes.END_ROD, 48);

                        for (int step = 2; step <= (int) bal.skillRadius; step += 2) {
                            Vec3d sample = eyeNow.add(lookNow.multiply(step));
                            for (LivingEntity target : getTargetsAround(world, player, sample, 2.0)) {
                                float mult = target.getType().isIn(EntityTypeTags.UNDEAD) ? 1.65F : 1.0F;
                                target.damage(world, world.getDamageSources().indirectMagic(player, player), bal.skillDamage * mult);
                                applyElementStatus(world, player, target, ElementType.HOLY, 2);
                            }
                        }
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 1));
                        ModNetworking.broadcastScreenEffect(world, eyeNow, 32.0, 0.5F, 10, 3, element.getFlashColor(), 5, 0.0F, 0);
                    }
                });
            }
        }
    }

    private static void executeUltimate(ServerWorld world, ServerPlayerEntity player, ElementType element, ModConfig.WeaponBalance bal) {
        Vec3d center = player.getPos();
        double radius = bal.ultimateRadius;

        ModNetworking.broadcastScreenEffect(
            world, center, ModConfig.get().maxVfxRenderDistance,
            0.35F, 25, 0, element.getFlashColor(), 0, 0.55F, 45
        );

        ServerTaskScheduler.scheduleSequence(player.getUuid(), 85, tick -> {
            if (tick < 25) {
                float progress = tick / 25.0F;
                if (tick % 3 == 0) {
                    ModSounds.playChargeTick(world, center, element, progress);
                }
                double ringRadius = radius * (1.0 - ParticleMath.easeInOutSine(progress) * 0.65);
                ParticleMath.spawnRing(world, center.add(0, 0.25 + progress * 3.5, 0), ringRadius, 36, element.getPrimaryParticle(), -0.04);
                ParticleMath.spawnSacredMandala(world, center.add(0, 0.1, 0), radius * 0.85, element == ElementType.HOLY ? 8 : 6, tick * 0.12, element.getPrimaryParticle(), element.getSecondaryParticle());
                return;
            }

            if (tick == 25) {
                ModSounds.playUltimateDetonation(world, center, element);
                ModNetworking.broadcastScreenEffect(
                    world, center, ModConfig.get().maxVfxRenderDistance,
                    0.9F, 30, 5, element.getFlashColor(), 14, 0.35F, 25
                );
            }

            if (tick >= 25 && tick <= 65) {
                switch (element) {
                    case FIRE -> {
                        if (tick % 4 == 0) {
                            double angle = world.random.nextDouble() * Math.PI * 2.0;
                            double r = world.random.nextDouble() * (radius - 1.5);
                            Vec3d impact = center.add(Math.cos(angle) * r, 0, Math.sin(angle) * r);
                            Vec3d skyStart = impact.add((world.random.nextDouble() - 0.5) * 4.0, 12.0, (world.random.nextDouble() - 0.5) * 4.0);
                            ParticleMath.spawnLine(world, skyStart, impact, element.getPrimaryParticle(), 22);
                            ParticleMath.spawnRing(world, impact.add(0, 0.2, 0), 3.2, 28, ParticleTypes.FLAME, 0.12);
                            world.spawnParticles(ParticleTypes.LAVA, impact.x, impact.y + 0.5, impact.z, 10, 0.4, 0.4, 0.4, 0.1);
                            world.playSound(null, impact.x, impact.y, impact.z, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 1.1F, 0.85F);

                            if (ModConfig.get().ultimateBlockDamage) {
                                world.createExplosion(player, impact.x, impact.y, impact.z, 2.0F, World.ExplosionSourceType.MOB);
                            }
                            for (LivingEntity target : getTargetsAround(world, player, impact, 4.0)) {
                                target.damage(world, world.getDamageSources().onFire(), bal.ultimateDamage * 0.35F);
                                target.setOnFireFor(12);
                            }
                        }
                    }
                    case ICE -> {
                        if (tick % 3 == 0) {
                            for (int lat = 1; lat <= 3; lat++) {
                                double phi = (lat / 4.0) * (Math.PI * 0.5);
                                double r = Math.cos(phi) * radius;
                                double y = Math.sin(phi) * radius;
                                ParticleMath.spawnRing(world, center.add(0, y, 0), r, 28, element.getPrimaryParticle(), 0.0);
                            }
                        }
                        if (tick % 5 == 0) {
                            for (LivingEntity target : getTargetsAround(world, player, center, radius)) {
                                target.damage(world, world.getDamageSources().freeze(), bal.ultimateDamage * 0.22F);
                                applyElementStatus(world, player, target, ElementType.ICE, 3);
                            }
                        }
                    }
                    case LIGHTNING -> {
                        if (tick % 4 == 0) {
                            double angle = ((tick - 25) / 40.0) * Math.PI * 4.0;
                            double r = radius * 0.65;
                            Vec3d strikePos = center.add(Math.cos(angle) * r, 0, Math.sin(angle) * r);
                            LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world, SpawnReason.TRIGGERED);
                            if (bolt != null) {
                                bolt.refreshPositionAfterTeleport(strikePos.x, strikePos.y, strikePos.z);
                                bolt.setCosmetic(!ModConfig.get().ultimateBlockDamage);
                                world.spawnEntity(bolt);
                            }
                            ParticleMath.spawnJaggedLightningBolt(world, strikePos.add(0, 14, 0), strikePos, element.getPrimaryParticle(), ParticleTypes.ELECTRIC_SPARK, 12, 0.7);
                            for (LivingEntity target : getTargetsAround(world, player, center, radius)) {
                                target.damage(world, world.getDamageSources().lightningBolt(), bal.ultimateDamage * 0.25F);
                                applyElementStatus(world, player, target, ElementType.LIGHTNING, 3);
                            }
                        }
                    }
                    case VOID -> {
                        Vec3d singularity = center.add(0, 4.5, 0);
                        ParticleMath.spawnRing(world, singularity, 3.0, 28, element.getPrimaryParticle(), -0.06);
                        if (tick % 4 == 0) {
                            double a1 = world.random.nextDouble() * Math.PI * 2.0;
                            Vec3d p1 = center.add(Math.cos(a1) * radius, 0.5 + world.random.nextDouble() * 4.0, Math.sin(a1) * radius);
                            Vec3d p2 = center.add(Math.cos(a1 + Math.PI) * radius, 0.5 + world.random.nextDouble() * 4.0, Math.sin(a1 + Math.PI) * radius);
                            ParticleMath.spawnLine(world, p1, p2, element.getPrimaryParticle(), 36);
                            world.playSound(null, center.x, center.y, center.z, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.3F, 0.55F);

                            for (LivingEntity target : getTargetsAround(world, player, center, radius)) {
                                Vec3d pull = singularity.subtract(target.getPos()).normalize().multiply(0.28);
                                target.addVelocity(pull.x, pull.y * 0.45, pull.z);
                                target.velocityModified = true;
                                target.damage(world, world.getDamageSources().outOfWorld(), bal.ultimateDamage * 0.24F);
                                applyElementStatus(world, player, target, ElementType.VOID, 3);
                            }
                        }
                    }
                    case HOLY -> {
                        double progress = (tick - 25) / 40.0;
                        double pillarR = radius * (1.0 - progress * 0.65);
                        for (int i = 0; i < 8; i++) {
                            double a = (2.0 * Math.PI * i) / 8.0 + progress * Math.PI;
                            Vec3d base = center.add(Math.cos(a) * pillarR, 0, Math.sin(a) * pillarR);
                            ParticleMath.spawnLine(world, base, base.add(0, 10.0, 0), element.getPrimaryParticle(), 12);
                        }
                        if (tick % 8 == 0) {
                            player.heal(3.0F);
                            player.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 200, 2));
                            player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 120, 1));
                            for (LivingEntity target : getTargetsAround(world, player, center, radius)) {
                                float mult = target.getType().isIn(EntityTypeTags.UNDEAD) ? 2.0F : 1.0F;
                                target.damage(world, world.getDamageSources().indirectMagic(player, player), bal.ultimateDamage * 0.25F * mult);
                                applyElementStatus(world, player, target, ElementType.HOLY, 3);
                            }
                        }
                    }
                }
            }

            if (tick == 66) {
                ModSounds.playUltimateDetonation(world, center, element);
                ParticleMath.spawnRing(world, center.add(0, 0.4, 0), radius, 64, element.getPrimaryParticle(), 0.22);
                for (LivingEntity target : getTargetsAround(world, player, center, radius)) {
                    target.damage(world, world.getDamageSources().playerAttack(player), bal.ultimateDamage * 0.45F);
                }
                ModNetworking.broadcastScreenEffect(
                    world, center, ModConfig.get().maxVfxRenderDistance,
                    0.75F, 18, 4, element.getFlashColor(), 10, 0.0F, 0
                );
            } else if (tick > 66 && tick % 3 == 0) {
                ParticleMath.spawnRing(world, center.add(0, 0.15, 0), radius * 0.7, 24, element.getSecondaryParticle(), 0.02);
            }
        });
    }

    private static void applyElementStatus(ServerWorld world, ServerPlayerEntity attacker, LivingEntity target, ElementType element, int tier) {
        switch (element) {
            case FIRE -> target.setOnFireFor(4 * tier);
            case ICE -> {
                target.setFrozenTicks(Math.min(400, target.getFrozenTicks() + 120 * tier));
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60 * tier, tier));
            }
            case LIGHTNING -> {
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 80 * tier, 0));
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25 * tier, 3));
            }
            case VOID -> {
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 60 * tier, tier));
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 60 * tier, 0));
            }
            case HOLY -> {
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 100 * tier, 0));
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 80 * tier, tier - 1));
                attacker.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 60 * tier, 0));
            }
        }
    }

    private static List<LivingEntity> getTargetsInCone(
        ServerWorld world,
        ServerPlayerEntity attacker,
        Vec3d origin,
        Vec3d look,
        double radius,
        double fovDegrees
    ) {
        double cosHalfAngle = Math.cos(Math.toRadians(fovDegrees * 0.5));
        Box box = Box.of(origin, radius * 2.2, radius * 1.5, radius * 2.2);
        List<LivingEntity> list = world.getEntitiesByClass(
            LivingEntity.class,
            box,
            e -> e != attacker && e.isAlive() && !e.isSpectator() && !e.isTeammate(attacker)
        );
        List<LivingEntity> filtered = new ArrayList<>();
        for (LivingEntity e : list) {
            Vec3d toTarget = e.getBoundingBox().getCenter().subtract(origin);
            double dist = toTarget.length();
            if (dist <= radius && (dist < 1.2 || toTarget.normalize().dotProduct(look) >= cosHalfAngle)) {
                filtered.add(e);
                if (filtered.size() >= ModConfig.get().maxAffectedEntities) {
                    break;
                }
            }
        }
        return filtered;
    }

    private static List<LivingEntity> getTargetsAround(
        ServerWorld world,
        ServerPlayerEntity attacker,
        Vec3d center,
        double radius
    ) {
        Box box = Box.of(center, radius * 2.0, radius * 2.0, radius * 2.0);
        double rSq = radius * radius;
        List<LivingEntity> list = world.getEntitiesByClass(
            LivingEntity.class,
            box,
            e -> e != attacker && e.isAlive() && !e.isSpectator() && !e.isTeammate(attacker) && e.squaredDistanceTo(center) <= rSq
        );
        if (list.size() > ModConfig.get().maxAffectedEntities) {
            return list.subList(0, ModConfig.get().maxAffectedEntities);
        }
        return list;
    }
}
