package com.elementalarsenal;

import com.elementalarsenal.client.ClientVfxState;
import com.elementalarsenal.item.ElementType;
import com.elementalarsenal.item.ElementalWeaponItem;
import com.elementalarsenal.network.ModNetworking;
import com.elementalarsenal.registry.ModParticles;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.particle.EndRodParticle;
import net.minecraft.client.particle.FlameParticle;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

public class ElementalArsenalClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModNetworking.registerClientReceivers();

        ParticleFactoryRegistry.getInstance().register(ModParticles.SOLAR_EMBER, FlameParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.FROST_SHARD, EndRodParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.STORM_SPARK, EndRodParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.VOID_WISP, EndRodParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.HOLY_MOTE, EndRodParticle.Factory::new);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientVfxState.tick();
            spawnLocalHeldAura(client);
        });
    }

    private void spawnLocalHeldAura(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || client.isPaused() || player.isSpectator() || !player.isAlive()) {
            return;
        }
        if (!(player.getMainHandStack().getItem() instanceof ElementalWeaponItem weapon)) {
            return;
        }

        ElementType type = weapon.getElementType();
        double time = world.getTime() * 0.12;
        double radius = 0.65;
        double px = player.getX() + Math.cos(time) * radius;
        double py = player.getBodyY(0.45) + Math.sin(time * 1.7) * 0.35;
        double pz = player.getZ() + Math.sin(time) * radius;

        world.addParticleClient(type.getPrimaryParticle(), px, py, pz, 0.0, 0.015, 0.0);
        if (world.getTime() % 3 == 0) {
            Vec3d look = player.getRotationVec(1.0F);
            Vec3d right = look.crossProduct(new Vec3d(0, 1, 0)).normalize();
            Vec3d handPos = player.getEyePos().add(look.multiply(0.55)).add(right.multiply(0.38)).add(0, -0.28, 0);
            world.addParticleClient(
                type == ElementType.VOID ? ParticleTypes.PORTAL : type.getSecondaryParticle(),
                handPos.x, handPos.y, handPos.z,
                (world.random.nextDouble() - 0.5) * 0.03,
                0.01,
                (world.random.nextDouble() - 0.5) * 0.03
            );
        }
    }
}
