#!/usr/bin/env python3
"""
Procedural Pixel-Art PNG Generator for Legendary Elemental Arsenal (Minecraft 1.21.11).
Requires ONLY the Python standard library (zlib, struct, math, pathlib) — no external dependencies needed.
Generates:
  - 15 weapon material/part textures (16x16 RGBA PNGs) in assets/elemental_arsenal/textures/item/
  - 5 custom particle textures (16x16 RGBA PNGs) in assets/elemental_arsenal/textures/particle/
  - 1 mod icon (128x128 RGBA PNG) in assets/elemental_arsenal/icon.png
"""

import math
import struct
import zlib
from pathlib import Path


def write_png(path: Path, width: int, height: int, pixels: list[tuple[int, int, int, int]]) -> None:
    """Writes an RGBA pixel buffer (list of (R, G, B, A) tuples) to a valid PNG file using stdlib only."""
    path.parent.mkdir(parents=True, exist_ok=True)
    raw_data = bytearray()
    for y in range(height):
        raw_data.append(0)  # Filter type 0 (None)
        row_start = y * width
        for x in range(width):
            r, g, b, a = pixels[row_start + x]
            raw_data.extend((
                max(0, min(255, int(r))),
                max(0, min(255, int(g))),
                max(0, min(255, int(b))),
                max(0, min(255, int(a))),
            ))

    def make_chunk(chunk_type: bytes, data: bytes) -> bytes:
        crc = zlib.crc32(chunk_type + data) & 0xFFFFFFFF
        return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", crc)

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)  # 8-bit RGBA
    compressed = zlib.compress(bytes(raw_data), level=9)
    png_bytes = (
        b"\x89PNG\r\n\x1a\n"
        + make_chunk(b"IHDR", ihdr)
        + make_chunk(b"IDAT", compressed)
        + make_chunk(b"IEND", b"")
    )
    path.write_bytes(png_bytes)


def lerpColor(c1: tuple[int, int, int], c2: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    t = max(0.0, min(1.0, t))
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t),
    )


def hash_noise(x: int, y: int, seed: int) -> float:
    n = x * 374761393 + y * 668265263 + seed * 1442695041
    n = (n ^ (n >> 13)) * 1274126177
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


def generate_blade_metal_texture(
    dark_rgb: tuple[int, int, int],
    mid_rgb: tuple[int, int, int],
    bright_rgb: tuple[int, int, int],
    seed: int,
) -> list[tuple[int, int, int, int]]:
    pixels = []
    for y in range(16):
        for x in range(16):
            # Diagonal metallic sheen + edge bevel + crystalline micro-grain
            center_dist = abs(x - 7.5) / 8.0
            diag_wave = 0.5 + 0.5 * math.sin((x + y) * 0.55 + seed)
            grain = (hash_noise(x, y, seed) - 0.5) * 0.18
            t = max(0.0, min(1.0, (1.0 - center_dist * 0.75) * 0.65 + diag_wave * 0.35 + grain))
            if t < 0.5:
                r, g, b = lerpColor(dark_rgb, mid_rgb, t * 2.0)
            else:
                r, g, b = lerpColor(mid_rgb, bright_rgb, (t - 0.5) * 2.0)
            # Highlighted bevel along outer 1px border
            if x in (0, 15) or y in (0, 15):
                r, g, b = lerpColor((r, g, b), dark_rgb, 0.45)
            elif x in (7, 8):
                r, g, b = lerpColor((r, g, b), bright_rgb, 0.4)
            pixels.append((r, g, b, 255))
    return pixels


def generate_core_glow_texture(
    edge_rgb: tuple[int, int, int],
    core_rgb: tuple[int, int, int],
    white_hot_rgb: tuple[int, int, int],
    seed: int,
) -> list[tuple[int, int, int, int]]:
    pixels = []
    for y in range(16):
        for x in range(16):
            dx = (x - 7.5) / 7.5
            dy = (y - 7.5) / 7.5
            radial = math.sqrt(dx * dx + dy * dy)
            rune_band = 0.5 + 0.5 * math.cos((y * 0.8) - (x * 0.4) + seed)
            pulse = max(0.0, min(1.0, 1.15 - radial * 0.85 + (rune_band - 0.5) * 0.25))
            if pulse < 0.55:
                r, g, b = lerpColor(edge_rgb, core_rgb, pulse / 0.55)
            else:
                r, g, b = lerpColor(core_rgb, white_hot_rgb, (pulse - 0.55) / 0.45)
            pixels.append((r, g, b, 255))
    return pixels


def generate_handle_texture(
    wrap_dark: tuple[int, int, int],
    wrap_light: tuple[int, int, int],
    trim_gold: tuple[int, int, int],
    seed: int,
) -> list[tuple[int, int, int, int]]:
    pixels = []
    for y in range(16):
        for x in range(16):
            # Cross-wrapped leather/obsidian grip pattern with metallic pommel bands
            if y in (0, 1, 14, 15):
                t = 0.5 + 0.5 * math.sin(x * 0.7 + seed)
                r, g, b = lerpColor(wrap_dark, trim_gold, 0.55 + 0.45 * t)
            else:
                band = ((x + y) % 4 == 0) or ((x - y) % 4 == 0)
                noise = hash_noise(x, y, seed) * 0.2
                base_t = (0.75 if band else 0.25) + noise
                r, g, b = lerpColor(wrap_dark, wrap_light, base_t)
            pixels.append((r, g, b, 255))
    return pixels


def generate_particle_texture(
    outer_rgb: tuple[int, int, int],
    inner_rgb: tuple[int, int, int],
    shape: str,
) -> list[tuple[int, int, int, int]]:
    pixels = []
    for y in range(16):
        for x in range(16):
            dx = (x - 7.5) / 7.5
            dy = (y - 7.5) / 7.5
            dist = math.sqrt(dx * dx + dy * dy)
            angle = math.atan2(dy, dx)

            if shape == "star":
                star_factor = 0.55 + 0.45 * abs(math.cos(angle * 2.0))
                eff_dist = dist / star_factor
            elif shape == "shard":
                diamond = abs(dx) * 1.15 + abs(dy) * 0.85
                eff_dist = diamond
            elif shape == "spark":
                zig = 0.6 + 0.4 * abs(math.sin(angle * 3.0))
                eff_dist = dist / zig
            elif shape == "vortex":
                spiral = 0.75 + 0.25 * math.sin(dist * 6.0 - angle * 2.0)
                eff_dist = dist * spiral
            else:  # halo / holy mote
                ring = abs(dist - 0.55) < 0.14
                eff_dist = dist * (0.72 if ring else 1.0)

            if eff_dist >= 1.0:
                pixels.append((0, 0, 0, 0))
            else:
                intensity = (1.0 - eff_dist) ** 1.4
                r, g, b = lerpColor(outer_rgb, inner_rgb, intensity)
                alpha = int(min(255, max(0, intensity * 255 * 1.25)))
                pixels.append((r, g, b, alpha))
    return pixels


def generate_mod_icon() -> list[tuple[int, int, int, int]]:
    width, height = 128, 128
    pixels = []
    element_colors = [
        (255, 90, 15),   # Fire
        (0, 215, 255),   # Ice
        (175, 90, 255),  # Lightning
        (110, 20, 210),  # Void
        (255, 225, 110), # Holy
    ]
    for y in range(height):
        for x in range(width):
            dx = (x - 63.5) / 63.5
            dy = (y - 63.5) / 63.5
            r_dist = math.sqrt(dx * dx + dy * dy)
            angle = (math.atan2(dy, dx) + math.pi) / (2.0 * math.pi)
            sector = int(angle * 5.0) % 5
            sec_col = element_colors[sector]

            bg = lerpColor((12, 10, 22), (28, 24, 48), 1.0 - min(1.0, r_dist))
            # Emblem ring + central star blade
            ring = abs(r_dist - 0.72) < 0.06
            diag_blade = abs(dx + dy) < 0.09 and r_dist < 0.78
            cross_guard = abs(dx - dy) < 0.26 and abs(dx + dy) < 0.22 and r_dist < 0.42
            if diag_blade or cross_guard:
                col = lerpColor(sec_col, (255, 255, 255), 0.65)
            elif ring:
                col = sec_col
            else:
                glow = max(0.0, 1.0 - abs(r_dist - 0.72) * 5.0) * 0.45
                col = lerpColor(bg, sec_col, glow)
            pixels.append((col[0], col[1], col[2], 255))
    return pixels


def main(base_dir: Path | None = None) -> None:
    root = base_dir if base_dir is not None else Path(__file__).resolve().parent.parent
    assets = root / "src" / "main" / "resources" / "assets" / "elemental_arsenal"
    item_tex_dir = assets / "textures" / "item"
    particle_tex_dir = assets / "textures" / "particle"

    palettes = {
        "fire": {
            "metal": ((35, 14, 14), (185, 38, 12), (255, 165, 30), 101),
            "core": ((190, 30, 5), (255, 140, 10), (255, 248, 195), 102),
            "handle": ((22, 12, 12), (68, 28, 22), (235, 155, 35), 103),
        },
        "ice": {
            "metal": ((14, 34, 68), (55, 175, 235), (225, 250, 255), 201),
            "core": ((20, 125, 210), (110, 238, 255), (245, 255, 255), 202),
            "handle": ((18, 28, 48), (65, 95, 135), (175, 235, 255), 203),
        },
        "lightning": {
            "metal": ((24, 20, 46), (115, 55, 210), (130, 230, 255), 301),
            "core": ((95, 30, 195), (185, 115, 255), (255, 250, 150), 302),
            "handle": ((20, 22, 36), (62, 58, 95), (245, 215, 70), 303),
        },
        "void": {
            "metal": ((8, 4, 18), (68, 16, 118), (195, 105, 255), 401),
            "core": ((42, 8, 82), (155, 55, 235), (240, 195, 255), 402),
            "handle": ((10, 6, 20), (44, 18, 72), (168, 85, 247), 403),
        },
        "holy": {
            "metal": ((165, 130, 65), (238, 205, 125), (255, 252, 240), 501),
            "core": ((235, 155, 45), (255, 220, 110), (255, 255, 255), 502),
            "handle": ((95, 72, 48), (225, 215, 195), (255, 215, 90), 503),
        },
    }

    for elem, cfg in palettes.items():
        write_png(item_tex_dir / f"{elem}_metal.png", 16, 16, generate_blade_metal_texture(*cfg["metal"]))
        write_png(item_tex_dir / f"{elem}_core.png", 16, 16, generate_core_glow_texture(*cfg["core"]))
        write_png(item_tex_dir / f"{elem}_handle.png", 16, 16, generate_handle_texture(*cfg["handle"]))

    particles = {
        "solar_ember": ((220, 45, 5), (255, 240, 150), "star"),
        "frost_shard": ((0, 150, 235), (235, 255, 255), "shard"),
        "storm_spark": ((135, 55, 255), (255, 252, 165), "spark"),
        "void_wisp": ((65, 10, 125), (225, 155, 255), "vortex"),
        "holy_mote": ((245, 180, 55), (255, 255, 255), "halo"),
    }
    for pname, pcfg in particles.items():
        write_png(particle_tex_dir / f"{pname}.png", 16, 16, generate_particle_texture(*pcfg))

    write_png(assets / "icon.png", 128, 128, generate_mod_icon())
    print(f"Generated 21 procedural PNG assets in {assets}")


if __name__ == "__main__":
    main()
